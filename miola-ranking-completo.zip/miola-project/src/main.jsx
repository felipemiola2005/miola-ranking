import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'

// Shared storage using localStorage
// All users on the same browser share data via the deployed URL
window.storage = {
  async get(key) {
    try {
      const val = localStorage.getItem(key);
      return val ? { value: val } : null;
    } catch { return null; }
  },
  async set(key, value) {
    try {
      localStorage.setItem(key, value);
      // Also sync via BroadcastChannel for same-device tabs
      try {
        const bc = new BroadcastChannel('miola_sync');
        bc.postMessage({ key, value });
        bc.close();
      } catch {}
      return { value };
    } catch { return null; }
  }
};

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
